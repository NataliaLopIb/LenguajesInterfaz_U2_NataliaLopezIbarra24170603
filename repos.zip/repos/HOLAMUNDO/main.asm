;Lenguajez de interfaz, Natalia Lopez Ibarra, 9-10, Jose Luis Medina Jimenez
INCLUDE Irvine32.inc

.data
    mensaje BYTE "Hola Mundo!", 0  

.code
main PROC
    mov edx, OFFSET mensaje        
    call WriteString              
    call Crlf                  

    exit                           
main ENDP

END main
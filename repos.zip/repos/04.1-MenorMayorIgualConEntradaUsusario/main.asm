;Lenguajes de Interfaz, Natalia Lopez Ibarra, 9-10, Jose Luis Medina Jimenez
INCLUDE Irvine32.inc

.data
n1 BYTE "Escribe el primer numero a comparar: ", 0
n2 BYTE "Escribe el segundo numero a comparar: ", 0

msgIguales BYTE "Los numeros son iguales", 0
msgMayor BYTE "El primer numero es mayor", 0
msgMenor BYTE "El primer numero es menor", 0

num1 DWORD ?
num2 DWORD ?

.code
main PROC

mov edx, OFFSET n1 
call WriteString 
call ReadInt ; Lee el primer numero ingresado por el usuario
mov num1, eax 

mov edx, OFFSET n2 
call WriteString 
call ReadInt ; Lee el segundo numero ingresado por el usuario
mov num2, eax 

mov eax, num1 
mov ebx, num2 

cmp eax, ebx 

je iguales ; Salta si son iguales
jg mayor ; Salta si el primero es mayor
jl menor ; Salta si el primero es menor

iguales:
mov edx, OFFSET msgIguales 
call WriteString 
jmp fin 

mayor:
mov edx, OFFSET msgMayor 
call WriteString 
jmp fin 

menor:
mov edx, OFFSET msgMenor 
call WriteString 

fin:
call Crlf 
exit 

main ENDP

END main
;Lenguajes de Interfaz, Natalia Lopez Ibarra, 9-10, Jose Luis Medina Jimenez
INCLUDE Irvine32.inc

.data
    mensaje BYTE "Escribe tu nombre: ", 0 ; Define una cadena de texto terminada en nulo (0) para interactuar con el usuario
    nombre BYTE 30 DUP(0)        ; Reserva un b�fer de 30 bytes inicializados en 0 para almacenar la entrada

.code
main PROC
   
    mov edx, OFFSET mensaje  ; Carga en EDX la direcci�n de memoria donde inicia la cadena a imprimir
    call WriteString  ; Ejecuta la rutina que imprime en consola la cadena apuntada por EDX

    ; Preparaci�n de registros para leer texto
    mov edx, OFFSET nombre 
    mov ecx, SIZEOF nombre ; Establece en ECX el l�mite m�ximo de caracteres para evitar desbordamiento (buffer overflow)

    call ReadString ; Lee la entrada del teclado (hasta presionar Enter) y la almacena en el b�fer de EDX

    ; Retorna lo escrito en el buffer
    mov edx, OFFSET nombre  ; Vuelve a apuntar EDX al inicio del b�fer que ahora contiene la respuesta
    call WriteString ; Imprime la cadena almacenada en la direcci�n proporcionada por EDX
    call Crlf ; saltolinea

    exit 

main ENDP

END main
